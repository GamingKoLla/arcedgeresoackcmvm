LOBBY MUSIC RESOURCE PACK (Minecraft Java 26.x)

1. REPLACE the placeholder tone:
   assets/lobby/sounds/theme.ogg  ->  your own track (must be .ogg Vorbis, named theme.ogg)
   (Convert MP3/WAV with Audacity or: ffmpeg -i song.mp3 -c:a libvorbis -q:a 4 theme.ogg)

2. RE-ZIP so pack.mcmeta is at the top level of the zip (not inside a folder).

3. INSTALL
   Singleplayer: put the zip in .minecraft/resourcepacks and enable it.
   Server: host the zip at a direct-download link, then in server.properties set
     resource-pack=<url>
     require-resource-pack=true
     resource-pack-sha1=<sha1 of the zip>

4. PLAY IT (command block / chat):
   /playsound lobby:theme music @a ~ ~ ~ 1 1 1
   Stop:  /stopsound @a music lobby:theme

5. LOOP: use a repeating command block with a timer = track length in ticks
   (20 ticks = 1 second; a 2-minute track = 2400 ticks).
